import conexao


destino = conexao.get_cursor()

def tipos_mov():
    print('Inserindo tipos de movimentação')
    
    insert = destino.prep("insert into pt_tipomov (codigo_tmv, descricao_tmv) values (?, ?)")

    valores = [
        ("A", "AQUISIÇÃO"),
        ("B", "BAIXA"),
        ("T", "TRANSFERÊNCIA"),
        ("R", "PR. CONTÁBIL"),
        ("P", "TRANS. PLANO")
    ]

    destino.executemany(insert, valores)

    conexao.commit()

def tipos_ajuste():
    print ("Inserindo Tipos de Ajuste")

    insert = destino.prep("insert into pt_cadajuste (codigo_aju, empresa_aju, descricao_aju) values (?, ?, ?)")

    valores = [(1, 1, "REAVALIAÇÃO(ANTES DO CORTE)")]

    destino.executemany(insert, valores)

    conexao.commit()

def baixas():
    print ("Inserindo Baixas")

    insert = destino.prep("insert into pt_cadbai (codigo_bai, empresa_bai, descricao_bai) values (?, ?, ?)")

    sql = """SELECT  descricao from baixas b """ 

    i = 0

    for row in conexao.get(sql):
        i += 1
        codigo_bai = i
        empresa_bai = 1
        descricao_bai = row["descricao"].strip(" ")

        destino.execute(insert, (codigo_bai, empresa_bai, descricao_bai))

    conexao.commit()

def tipos_bens():
    print("Inserindo Tipos de Bens")

    insert = destino.prep("insert into pt_cadtip(codigo_tip, empresa_tip, descricao_tip) values (?, ?, ?)")

    sql = """SELECT DESC_CONTA  FROM contdepr c """

    i = 0

    for row in conexao.get(sql):
        i += 1
        codigo_tip = i
        empresa_tip = 1
        descricao_tip = row['desc_conta'].strip(" ")

        destino.execute(insert, (codigo_tip, empresa_tip, descricao_tip))
        
    conexao.commit()

def situacao():
    print("Convertendo Situações")

    insert = destino.prep("INSERT INTO PT_CADSIT (CODIGO_SIT, EMPRESA_SIT, DESCRICAO_SIT) VALUES (?, ?, ?)")

    destino.execute(insert, (1, 1, "BOM"))

    conexao.commit()

def converte_grupos():
    print ("Convertendo grupos")
    
    insert = destino.prep("""insert into pt_cadpatg (codigo_gru,empresa_gru,nogru_gru) values (?,?,?)""")

    codigo_gru = 1
    nogru_gru = "Geral"

    destino.execute(insert, (codigo_gru,1,nogru_gru))

    conexao.commit()

def converte_responsaveis():
    print ("Convertendo responsaveis")

    insert = destino.prep("""insert into pt_cadresponsavel(codigo_resp, nome_resp) values(?,?)""")

    sql = """select cod_resp,descricao from responsa r"""

    for row in conexao.get(sql):
        codigo_resp = row['cod_resp']
        nome_resp = row['descricao'].strip(" ")

        destino.execute(insert, (codigo_resp, nome_resp))

    conexao.commit()

def converte_unidades():
    print ("Convertendo unidades")

    insert = destino.prep("""INSERT INTO pt_cadpatd(empresa_des,
	                                                codigo_des,
                                                    nauni_des,
                                                    ocultar_des)
                             VALUES (?,?,?,?)""")

    i = 0

    i += 1
    empresa_des = 1
    codigo_des = i
    nauni_des = "PREFEITURA MUNICIPAL"
    ocultar_des = "N"
    
    destino.execute(insert, (empresa_des, codigo_des, nauni_des, ocultar_des))

    conexao.commit()

def converte_subunidades():
    print("Convertendo Sub-Unidades")

    insert = destino.prep("insert into pt_cadpats (empresa_set, codigo_set, codigo_des_set, noset_set, responsa_set, codigo_resp_set) values (?, ?, ?, ?, ?, ?)")

    sql = """select setores.* ,
            r.DESCRICAO as nome
        from
            (
            select
                s.cod_setor,
                s.descricao,
                (
                select
                    top 1 mv.cod_resp
                from
                    moveis mv
                where
                    s.cod_setor = mv.cod_setor
                order by
                    data_aquisic desc) as responsavel
            from
                setor s) as setores
        left join responsa r on
            r.COD_RESP = setores.responsavel"""

    for row in conexao.get(sql):
        empresa_set = 1
        codigo_set = row['cod_setor']
        codigo_des_set = 1
        noset_set = row["descricao"].strip(" ")
        responsa_set = row["nome"]
        codigo_resp_set = row["responsavel"]

        destino.execute(insert,(empresa_set, codigo_set, codigo_des_set, noset_set, responsa_set, codigo_resp_set))
    
    conexao.commit()