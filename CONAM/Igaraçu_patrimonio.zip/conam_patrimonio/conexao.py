import fdb 
from fdb.fbcore import Cursor
import pyodbc

conexao_destino = fdb.connect(dsn="localhost:C:\Fiorilli\SCPI_8\Cidades\Igaracu_do_Tiete-PM\ARQ2021\SCPI2021.FDB", user='fscscpi8',
                     password='scpi', port=3050, charset='WIN1252')

conexao_origem = pyodbc.connect('DRIVER={SQL Server};SERVER=localhost;PORT=1433;DATABASE=patrimonio_igaracu;UID=sa;PWD=Dnal250304')

cursor_origem = conexao_origem.cursor()

cursor_destino = conexao_destino.cursor()

def commit():
    conexao_destino.commit()

def get_cursor():
    return conexao_destino.cursor()

internal_cursor = conexao_origem.cursor()

def get(sql):
    internal_cursor.execute(sql)
    columns = [i[0].lower() for i in internal_cursor.description]
    return [dict(zip(columns, row)) for row in internal_cursor]    