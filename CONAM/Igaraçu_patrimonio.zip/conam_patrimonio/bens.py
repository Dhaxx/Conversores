import conexao

destino = conexao.get_cursor()

def converte_bens():
    print("Convertendo bens Patrimoniais")
  
    destino.execute("DELETE FROM PT_MOVBEM")
    destino.execute("DELETE FROM PT_CADPAT")

    sql = """select
                n_bem,
                'M' as tipobem,
                n_chapa,
                cod_setor,
                n_docfiscal,
                n_fornecedor,
                descricao,
                data_aquisic,
                data_incorpora,
                vl_incorporacao,
                vl_atual,
                null as escritura,
                null as area,
                replace(conta_plano, '.', '') as conta
            from
                moveis m
            union
                            select
                n_bem,
                'I' as tipobem,
                null,
                null,
                '0000000000',
                455,
                descricao,
                data_aquisicao,
                data_incorpora,
                vl_incorporacao,
                vl_atual,
                escritura,
                area,
                replace(conta_plano, '.', '') as conta
            from
                imoveis i
            where
                n_bem <> ''
            order by
                tipobem asc """

    insert = """insert into pt_cadpat (codigo_pat,
                    empresa_pat,
                    codigo_gru_pat,
                    chapa_pat,
                    codigo_set_pat,
                    codigo_set_atu_pat,
                    nota_pat,
                    orig_pat,
                    codigo_for_pat,
                    codigo_tip_pat,
                    codigo_sit_pat,
                    discr_pat,
                    datae_pat,
                    dtlan_pat,
                    codigo_bai_pat,
                    valaqu_pat,
                    valatu_pat,
                    quan_pat,
                    valres_pat,
                    dt_contabil,
                    codant1,
                    codant2,
                    escr_pat,
                    areatot_pat,
                    codigo_cpl_pat)
                values(?,?,?,?,?,?,
                       ?,?,?,?,?,?,
                       ?,?,?,?,?,?,
                       ?,?,?,?,?,?,
                       ?)"""

    i = 0
    z = 0

    for row in conexao.get(sql):
        i += 1
        z += 1
        codigo_pat = i
        empresa_pat = 1
        codigo_gru_pat = 1
        chapa_pat = (row['n_chapa'].lstrip('0')).zfill(6) if row['n_chapa'] is not None else ('999' + str(int(i))).zfill(6)
        codigo_set_pat = int(row['cod_setor']) if row['cod_setor'] is not None else row['cod_setor']
        codigo_set_atu_pat = codigo_set_pat
        nota_pat = row['n_docfiscal']
        orig_pat = 'C'
        codigo_for_pat = 9 if row['n_fornecedor'] == 0 else row['n_fornecedor']
        codigo_tip_pat = 2
        codigo_sit_pat = 1
        discr_pat = row['descricao'].split("    ")[0]
        datae_pat = row['data_aquisic']
        dtlan_pat = row['data_incorpora']
        codigo_bai_pat = None
        valaqu_pat = row['vl_incorporacao']
        valatu_pat = row['vl_atual']
        quan_pat = 1
        valres_pat = 0
        dt_contabil = dtlan_pat
        codant1 = row['tipobem']
        codant2 = row['n_bem']
        escr_pat = row['escritura']
        areatot_pat = row['area']
        codigo_cpl_pat = row['conta']

        destino.execute(insert,(codigo_pat,empresa_pat,codigo_gru_pat,chapa_pat,codigo_set_pat,
                                codigo_set_atu_pat,nota_pat,orig_pat,codigo_for_pat,codigo_tip_pat,
                                codigo_sit_pat,discr_pat,datae_pat,dtlan_pat,codigo_bai_pat,
                                valaqu_pat,valatu_pat,quan_pat,valres_pat,dt_contabil,codant1,
                                codant2,escr_pat,areatot_pat, codigo_cpl_pat))
    conexao.commit()  

def movimentacao():
    print("Lançando Movimentação de Baixas")

    insert = destino.prep("""insert into pt_movbem(codigo_mov,
                                    empresa_mov,
                                    codigo_pat_mov,
                                    data_mov,
                                    codigo_set_mov,
                                    valor_mov,
                                    documento_mov,
                                    historico_mov,
                                    percentual_mov,
                                    dt_contabil,
                                    tipo_mov,
                                    codigo_cpl_mov)
                                values (?,?,?,?,
                                        ?,?,?,?,
                                        ?,?,?,?)""")

    sql = """select i.n_bem,
                    case
                        m.tipo_documento when 'AD' then 'A'
                        when 'AI' then 'A'
                        when 'AV' then 'R'
                        WHEN 'BX' then 'B'
                    END as tipomov,
                    i.descricao,
                    m.[DATA],
                    m.cod_setor,
                    case
                        m.tipo_documento when 'BX' then m.vl_movimento * -1
                        else m.vl_movimento
                    end as valor,
                    m.n_documento,
                    'I' as tipobem,
                    replace(m.conta_plano, '.', '') as conta
                from
                    imoveis i
                inner join moviment m on
                    (i.n_bem = m.n_bem)
                    and m.conta_plano like '1.2.3.2%'
                UNION 
                select
                    mv.n_bem,
                    case
                        m.tipo_documento
                    when 'AV' then 'R'
                        when 'GT' then 'T'
                        when 'DO' then 'T'
                        when 'BX' then 'B'
                        when 'DT' then 'T'
                        when 'AM' then 'A'
                    end as tipo_mov,
                        mv.descricao,
                        m.[DATA],
                        m.cod_setor,
                    case 
                        m.tipo_documento 
                    when 'DO' then m.vl_movimento * 0
                        when 'BX' then m.vl_movimento * -1
                        when 'DT' then m.vl_movimento * 0
                    end as valor,
                        m.n_documento,
                        'M' as tipobem,
                        replace(m.conta_plano, '.', '') as conta
                from
                    moveis mv
                inner join moviment m on
                    (mv.n_bem = m.n_bem)
                    and m.conta_plano like '1.2.3.1%'
                ORDER by
                    tipobem"""

    update = destino.prep("""update pt_cadpat set dtpag_pat= ?, codigo_bai_pat = ?, codigo_cpl_pat = ? where codigo_pat = ? """)

    listagem_valores = destino.execute("select codigo_pat, chapa_pat, valaqu_pat, valatu_pat, codant1, codant2 from pt_cadpat pc ").fetchallmap()

    listagem_baixas = destino.execute("""select descricao_bai , codigo_bai from pt_cadbai pc """).fetchallmap()

    i= 0

    for row in conexao.get(sql):
        i += 1
        codigo_mov = i
        empresa_mov = 1
        codigo_pat_mov = next((x['codigo_pat'] for x in listagem_valores if x['codant2'] == row['n_bem'] and x['codant1'] == row['tipobem']), None)
        data_mov = row['data'].strip("   ")
        codigo_set_mov = row['cod_setor'] if row['cod_setor'] != '     ' else None
        valor_mov = row['valor']
        documento_mov = row['n_documento']
        historico_mov = row['descricao'].split("    ")[0]
        codigo_bai_mov = next((x["codigo_bai"] for x in listagem_baixas if x["descricao_bai"] == row["descricao"]), 2)
        percentual_mov = 0
        dt_contabil = data_mov
        tipo_mov = row['tipomov']  
        codigo_cpl_mov = row['conta']     

        destino.execute(insert,(codigo_mov, empresa_mov, codigo_pat_mov, data_mov, codigo_set_mov, valor_mov, documento_mov, 
                                historico_mov, percentual_mov, dt_contabil, tipo_mov, codigo_cpl_mov))
        if tipo_mov == 'B':
            destino.execute(update,(data_mov,codigo_bai_mov,codigo_cpl_mov,codigo_pat_mov))

    conexao.commit()  
